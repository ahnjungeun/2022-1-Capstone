import MyComponent from "./components/MyComponent";



function App() {
  return (
    <>
      <MyComponent></MyComponent>
    </>

  );

}

export default App;
